const url = "https://harry-potter-api.onrender.com/db"

fetch(url)
	.then((res) => res.json())
	.then((data) => {
		
		{
			"id"; 1,
			"tipo"; "Autora",
			"contenido"; "J. K. Rowling"
		  };
		  {
			"id"; 2,
			"tipo"; "Protagonísta",
			"contenido"; "Harry Potter"
		  };
		  {
			"id"; 3,
			"tipo"; "Antagonísta",
			"contenido"; "Lord Voldemort"
		  };
		  {
			"id"; 4,
			"tipo"; "Varita mágica de Harry Potter",
			"contenido"; "La varita de Harry Potter tenía 11 de largo, estaba hecha de acebo y poseía un núcleo de plumas de fénix. Esto fue descrito por Garrick Ollivander como una combinación inusual de núcleo de varita y madera. La pluma fue donada por Fawkes, el fénix de Albus Dumbledore."
		  };
		  {
			"id"; 5,
			"tipo"; "Varita mágica de Lord Voldemort",
			"contenido"; "La varita de Lord Voldemort tenía 11 de largo, estaba hecha de acebo y poseía un núcleo de plumas de fénix. Esto fue descrito por Garrick Ollivander como una combinación inusual de núcleo de varita y madera. La pluma fue donada por Fawkes, el fénix de Albus Dumbledore."
		  };
		  {
			"id"; 6,
			"tipo"; "Nombre real de Lord Voldemort",
			"contenido"; "Su nombre real es Tom Marvolo Riddle (mezclando las letras se forma Lord Voldemort)"
		  };
		  {
			"id"; 7,
			"tipo"; "Casas",
			"contenido"; "En la escuela Hogwarts hay cuatro casas: Gryffindor, Ravenclaw, Hufflepuff y Slytherin."
		  };
		  {
			"id";  8,
			"tipo"; "Varitas",
			"contenido"; "La varita de Harry y la varita de Voldemort eran gemelas, por eso ellos no podían matarse entre sí."
		  }
		console.log(data)
	})
	.catch((e) => console.log(e))